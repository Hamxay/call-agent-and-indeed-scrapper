# Two-Way Conversation Flow Documentation

## Overview
The Call Agent system now supports **two-way conversations** where the AI agent can ask questions and the user can respond naturally, creating an interactive phone experience.

## New Routes Added

### 1. `/calls/conversation-start` (POST)
- **Purpose**: Initializes a new conversation session
- **Flow**: 
  - Plays initial greeting message
  - Gets AI agent's first question
  - Sets up speech recognition to listen for user input
  - Redirects to conversation handler

### 2. `/calls/conversation-handler` (POST)
- **Purpose**: Handles ongoing conversation with user input
- **Flow**:
  - Receives user speech input via Twilio's Speech Recognition
  - Sends user input to Lyzr.ai agent for processing
  - Gets AI response and plays it back
  - Sets up next listening session
  - Handles conversation ending (when user says "goodbye")

### 3. `/calls/dtmf-handler` (POST)
- **Purpose**: Handles keypad input as alternative to speech
- **Options**:
  - Press `1`: Continue conversation
  - Press `2`: End call
  - Press `3`: Repeat last message

### 4. `/calls/conversation-end` (POST)
- **Purpose**: Gracefully ends conversations
- **Flow**: Plays goodbye message and hangs up

## How It Works

### Call Flow:
1. **Call Initiation**: User calls `/calls/make-call` endpoint
2. **Conversation Start**: Twilio calls `/calls/conversation-start` webhook
3. **AI Greeting**: Lyzr.ai agent provides initial question
4. **User Response**: Twilio listens for user speech input
5. **AI Processing**: User input sent to Lyzr.ai for response
6. **AI Response**: AI response played back to user
7. **Loop Continues**: Steps 4-6 repeat until user ends call
8. **Call End**: User says "goodbye" or uses keypad to end

### Speech Recognition Features:
- **Enhanced Speech Model**: Uses `phone_call` model for better phone audio
- **Auto Timeout**: Automatically handles silence and provides options
- **Fallback Options**: DTMF keypad input when speech fails
- **Natural Language**: Users can say "goodbye", "stop", "end call" to end

### AI Agent Integration:
- **Context Awareness**: Maintains conversation context
- **Dynamic Responses**: Generates natural follow-up questions
- **Conversational Flow**: Keeps dialogue engaging and natural
- **Session Management**: Tracks conversation state

## Configuration

### Environment Variables Required:
```bash
# Twilio Configuration
TWILIO_ACCOUNT_SID=your_account_sid
TWILIO_AUTH_TOKEN=your_auth_token
TWILIO_PHONE_NUMBER=your_twilio_number
BASE_URL=your_ngrok_url

# Lyzr Agent Configuration
LYZR_API_KEY=your_lyzr_api_key
LYZR_USER_ID=your_user_id
LYZR_AGENT_ID=your_agent_id
```

### Twilio Phone Number Setup:
- **Voice Webhook**: `https://your-domain.com/calls/conversation-start`
- **HTTP Method**: `POST`

## Testing

### Test the Conversation Flow:
```bash
# Test call initiation
curl -X POST https://your-domain.com/calls/make-call \
  -H "Content-Type: application/json" \
  -d '{"phone_number": "+1234567890", "message": "Hello! Let\'s chat!"}'

# Test Lyzr agent directly
curl -X POST https://your-domain.com/calls/test-lyzr \
  -H "Content-Type: application/json" \
  -d '{"message": "Test message", "session_id": "test123"}'
```

### Run Test Script:
```bash
python test_conversation_flow.py
```

## Key Benefits

1. **Natural Conversations**: AI asks questions and listens to responses
2. **Speech Recognition**: High-quality phone call speech processing
3. **Fallback Options**: DTMF keypad when speech fails
4. **Context Awareness**: AI remembers conversation flow
5. **Graceful Ending**: Natural ways to end calls
6. **Error Handling**: Robust fallbacks for technical issues

## Troubleshooting

### Common Issues:
1. **"Application Error"**: Check if all routes are accessible
2. **No Speech Recognition**: Verify Twilio Speech Recognition is enabled
3. **AI Not Responding**: Check Lyzr.ai API configuration
4. **Call Hanging Up**: Ensure webhook URLs are correct

### Debug Steps:
1. Check application logs for errors
2. Verify all environment variables are set
3. Test individual endpoints manually
4. Check Twilio call logs for webhook failures

## Future Enhancements

- **Multi-language Support**: Add support for different languages
- **Call Recording**: Store and analyze conversation recordings
- **Analytics**: Track conversation quality and user satisfaction
- **Custom Voices**: Allow selection of different AI voices
- **Integration**: Connect with CRM systems for lead management 