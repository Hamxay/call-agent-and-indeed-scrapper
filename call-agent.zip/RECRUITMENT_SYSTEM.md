# 🏢 Recruitment Agency Calling System

## Overview
The Recruitment Agency Calling System is a specialized AI-powered phone system that automatically calls recruitment agencies to inquire about job candidates. The AI agent acts as an HR recruiter, conducts professional conversations, and saves all interaction data to Excel files.

## 🎯 **Key Features**

### **1. Job-Specific Calls**
- **Job details included** in every call (title, company, experience, salary, location)
- **Professional HR persona** - AI acts as a real HR recruiter
- **Context-aware conversations** - AI remembers job requirements throughout the call

### **2. Automated Data Collection**
- **Excel file storage** - All call data saved to `recruitment_calls.xlsx`
- **Fallback text storage** - Backup to `recruitment_calls.txt` if Excel fails
- **Comprehensive tracking** - Call SID, timestamps, responses, status, job details

### **3. Professional Conversation Flow**
- **Agency introduction** - AI introduces itself and the position
- **Candidate inquiry** - Asks about available candidates
- **Process questions** - Gathers information about recruitment process
- **Follow-up questions** - Professional conversation continuation
- **Graceful ending** - Professional call termination

## 🚀 **How It Works**

### **Call Flow:**
1. **Job Details Input** → User provides job requirements
2. **Call Initiation** → System calls recruitment agency
3. **AI Introduction** → AI introduces as HR recruiter with job details
4. **Agency Response** → Agency responds about candidates
5. **AI Follow-up** → AI asks professional follow-up questions
6. **Data Collection** → All responses and details collected
7. **Data Storage** → Information saved to Excel/Word files
8. **Call Completion** → Professional call ending

### **Data Storage Fields:**
- **Call SID** - Unique Twilio call identifier
- **Timestamp** - When the call was made
- **Phone Number** - Agency contact number
- **Job Title** - Position being recruited for
- **Company** - Company name
- **Experience Level** - Required experience
- **Salary Range** - Compensation details
- **Location** - Job location
- **Last Response** - Agency's final response
- **Call Status** - How the call ended
- **Duration** - Call length (if available)

## 📱 **API Endpoints**

### **1. `/calls/recruitment-call` (POST)**
**Purpose**: Initiate a recruitment call with job details

**Required Fields:**
```json
{
  "phone_number": "+1234567890",
  "job_title": "Senior Python Developer"
}
```

**Optional Fields:**
```json
{
  "job_description": "Detailed job description",
  "company_name": "TechCorp Solutions",
  "experience_level": "5+ years",
  "salary_range": "$80,000 - $120,000",
  "location": "Remote/New York"
}
```

**Response:**
```json
{
  "success": true,
  "message": "Recruitment call initiated successfully",
  "call_sid": "CA1234567890",
  "phone_number": "+1234567890",
  "job_title": "Senior Python Developer",
  "conversation_type": "recruitment_agency_call",
  "webhook_url": "https://domain.com/calls/recruitment-start"
}
```

### **2. `/calls/get-recruitment-data` (GET)**
**Purpose**: Retrieve all recruitment call data

**Response:**
```json
{
  "success": true,
  "data": [
    {
      "Call SID": "CA1234567890",
      "Timestamp": "2024-01-15 14:30:00",
      "Phone Number": "+1234567890",
      "Job Title": "Senior Python Developer",
      "Company": "TechCorp Solutions",
      "Experience Level": "5+ years",
      "Salary Range": "$80,000 - $120,000",
      "Location": "Remote/New York",
      "Last Response": "We have 3 suitable candidates",
      "Call Status": "ended_by_agency"
    }
  ]
}
```

## 🔧 **Configuration**

### **Environment Variables Required:**
```bash
# Twilio Configuration
TWILIO_ACCOUNT_SID=your_account_sid
TWILIO_AUTH_TOKEN=your_auth_token
TWILIO_PHONE_NUMBER=your_twilio_number
BASE_URL=your_ngrok_url

# Lyzr Agent Configuration
LYZR_API_KEY=your_lyzr_api_key
LYZR_USER_ID=your_user_id
LYZR_AGENT_ID=your_agent_id
```

### **Twilio Phone Number Setup:**
- **Voice Webhook**: `https://your-domain.com/calls/recruitment-start`
- **HTTP Method**: `POST`

## 📊 **Data Storage**

### **Excel File Structure:**
The system automatically creates `recruitment_calls.xlsx` with columns:
- Call SID
- Timestamp
- Phone Number
- Job Title
- Company
- Experience Level
- Salary Range
- Location
- Last Response
- Call Status
- Duration

### **Fallback Storage:**
If Excel creation fails, data is saved to `recruitment_calls.txt` in format:
```
2024-01-15 14:30:00 | CA1234567890 | +1234567890 | Senior Python Developer | ended_by_agency
```

## 🧪 **Testing**

### **Test Recruitment Call:**
```bash
curl -X POST https://your-domain.com/calls/recruitment-call \
  -H "Content-Type: application/json" \
  -d '{
    "phone_number": "+1234567890",
    "job_title": "Senior Python Developer",
    "company_name": "TechCorp Solutions",
    "experience_level": "5+ years",
    "salary_range": "$80,000 - $120,000",
    "location": "Remote/New York"
  }'
```

### **Get Recruitment Data:**
```bash
curl -X GET https://your-domain.com/calls/get-recruitment-data
```

### **Run Test Script:**
```bash
python test_recruitment_flow.py
```

## 💼 **Use Cases**

### **1. Mass Recruitment Campaigns**
- Call multiple agencies for the same position
- Track responses and candidate availability
- Compare agency offerings and rates

### **2. Specific Skill Hiring**
- Target agencies specializing in specific skills
- Gather detailed candidate information
- Track market rates for specific positions

### **3. Agency Relationship Management**
- Track which agencies have responded
- Monitor call outcomes and follow-up needs
- Build database of agency capabilities

### **4. Compliance and Documentation**
- Maintain call records for compliance
- Document agency responses and commitments
- Track recruitment campaign effectiveness

## 🎭 **AI Agent Behavior**

### **Professional Persona:**
- **Role**: HR Recruiter
- **Tone**: Professional and courteous
- **Language**: Business-appropriate
- **Questions**: Focused on recruitment needs

### **Conversation Skills:**
- **Introduction**: Clear company and position introduction
- **Inquiry**: Specific questions about candidate availability
- **Follow-up**: Professional follow-up questions
- **Closing**: Graceful call termination

### **Intelligence Features:**
- **Context Awareness**: Remembers job details throughout call
- **Response Adaptation**: Adjusts based on agency responses
- **Professional Language**: Uses appropriate business terminology
- **Goal Orientation**: Focuses on gathering recruitment information

## 📈 **Analytics and Reporting**

### **Data Insights Available:**
- **Call Success Rates** - How many calls resulted in candidate leads
- **Agency Response Patterns** - Which agencies are most responsive
- **Job Market Trends** - Candidate availability by position type
- **Recruitment Costs** - Time and resources spent per successful hire

### **Export Options:**
- **Excel Format** - For detailed analysis and reporting
- **CSV Export** - For integration with other systems
- **API Access** - For real-time dashboard integration

## 🔒 **Security and Privacy**

### **Data Protection:**
- **Call Recording**: Optional call recording for quality assurance
- **Data Encryption**: Secure storage of sensitive information
- **Access Control**: API endpoints for authorized users only
- **Audit Trail**: Complete logging of all system activities

## 🚀 **Getting Started**

### **Step 1: Setup Environment**
1. Copy your `env.example` to `.env`
2. Fill in Twilio and Lyzr credentials
3. Set your `BASE_URL` to your ngrok domain

### **Step 2: Configure Twilio**
1. Set voice webhook to `/calls/recruitment-start`
2. Enable speech recognition
3. Configure call recording if needed

### **Step 3: Test the System**
1. Run `python test_recruitment_flow.py`
2. Make a test recruitment call
3. Verify data is saved to Excel

### **Step 4: Production Use**
1. Update phone numbers for real agencies
2. Configure job details for your positions
3. Monitor call outcomes and data quality

## 🎯 **Success Metrics**

### **Key Performance Indicators:**
- **Call Success Rate**: Percentage of calls that gather useful information
- **Data Quality**: Completeness and accuracy of collected information
- **Time Efficiency**: Time saved compared to manual calling
- **Lead Generation**: Number of candidate leads generated per call

### **Optimization Opportunities:**
- **Call Timing**: Best times to reach agency representatives
- **Question Refinement**: Most effective questions for gathering information
- **Response Analysis**: Understanding common agency responses
- **Follow-up Strategy**: Optimal timing and approach for follow-up calls

This recruitment system transforms manual agency calling into an automated, intelligent, and data-driven process that saves time and improves recruitment outcomes. 