# GetOnCall.AI - Backend

## Table of Contents
1. [Overview](#overview)
2. [Setting Up the Environment](#setting-up-the-environment)
3. [Installing Dependencies](#installing-dependencies)
4. [Creating the .env File](#creating-the-env-file)
5. [Setting Up the Database](#setting-up-the-database)
6. [Running Migrations](#running-migrations)
7. [Starting the Server](#starting-the-server)
8. [Automated Outbound Calls](#automated-outbound-calls)
9. [Linked Repositories](#linked-repositories)

---

## Overview

GetOnCall.AI is an automated call agent system that contacts staffing agencies to inquire about available frontline roles (Server, Cook, Housekeeper, Nursing Assistant). The system integrates with Lyzr AI agents for intelligent conversation handling and Twilio for voice communication.

### Key Features
- **Automated Outbound Calls**: Automated staffing inquiries for specific roles
- **Lyzr AI Integration**: Intelligent conversation handling with pre-configured agents
- **Call Recording & Transcription**: Complete call tracking and analysis
- **Secure Communication**: JWT authentication and encrypted data storage
- **Real-time Status Tracking**: Monitor call progress and results

---

## Setting Up the Environment

### On Windows
1. Open Command Prompt or PowerShell.
2. Install `venv` if not already installed: `pip install virtualenv`.
3. Create a virtual environment: `python -m venv venv`.
4. Activate the environment: `venv\Scripts\activate`.

### On macOS/Linux
1. Open Terminal.
2. Create a virtual environment: `python3 -m venv venv`.
3. Activate the environment: `source venv/bin/activate`.

---

## Installing Dependencies
1. Ensure your virtual environment is activated.
2. Install the project dependencies:
   ```bash
   pip install -r requirements.txt
   ```

---

## Creating the .env File
1. Copy the `.env.example` file to create a new `.env` file:
   ```bash
   cp .env.example .env  # For macOS/Linux
   copy .env.example .env  # For Windows
   ```
2. Open the `.env` file and update the necessary environment variables:

### Required Environment Variables
```bash
# Database
DATABASE_URI=postgresql://username:password@host:port/database_name

# Twilio Configuration
TWILIO_ACCOUNT_SID=your_twilio_account_sid
TWILIO_API_KEY=your_twilio_api_key
TWILIO_API_SECRET=your_twilio_api_secret
TWIML_APP_SID=your_twiml_app_sid
TWILIO_AUTH_TOKEN=your_twilio_auth_token
TWILIO_PHONE_NUMBER=your_twilio_phone_number

# Lyzr Agent API Configuration
LYZR_API_KEY=sk-default-TkM2vZ53V0tzne4sNDX1vVtZMow8TDXn
LYZR_USER_ID=hamxay341@gmail.com
LYZR_AGENT_ID=68b94c0c38e044156b375fb4

# Other Services
DEEPGRAM_API_KEY=your_deepgram_api_key
ANTHROPIC_API_KEY=your_anthropic_api_key
SECRET_KEY=your_secret_key
```

---

## Setting Up the Database

### Option 1: Using pgAdmin
1. Open pgAdmin and log in to your PostgreSQL instance.
2. Create a new database by right-clicking on "Databases" and selecting "Create > Database".
3. Enter your desired database name and save.

### Option 2: Using Command Line
1. Open Terminal or Command Prompt.
2. Access PostgreSQL:
   ```bash
   psql -U postgres
   ```
3. Create a new database:
   ```sql
   CREATE DATABASE your_database_name;
   ```
4. Exit PostgreSQL:
   ```sql
   \q
   ```

5. Update the `.env` file with your database connection string:
   ```text
   DATABASE_URI=postgresql://username:password@database_host:database_port/your_database_name
   ```

---

## Running Migrations
1. Ensure your virtual environment is activated.
2. Run the database migrations:
   ```bash
   flask db upgrade
   ```

**Note**: The system now includes new fields for automated outbound calls. Make sure to run migrations to add these fields.

---

## Starting the Server
1. Activate your virtual environment if not already activated.
2. Start the server:
   ```bash
   flask run --host=0.0.0.0 --port=5000
   ```
3. Access the app in your browser at: [http://0.0.0.0:5000](http://0.0.0.0:5000).

---

## Automated Outbound Calls

### Overview
The system now supports automated outbound calls for staffing inquiries using Lyzr AI agents. Users can initiate calls for specific roles and the system will handle the entire process automatically.

### API Endpoints

#### Initiate Automated Call
```bash
POST /calls/automated-outbound
Authorization: Bearer <jwt_token>

{
  "target_phone": "+1234567890",
  "role_type": "Server",
  "company_name": "Restaurant Name"
}
```

#### Check Call Status
```bash
GET /calls/automated-outbound/{call_id}/status
Authorization: Bearer <jwt_token>
```

### Supported Role Types
- Server
- Cook
- Housekeeper
- Nursing Assistant

### Testing
Use the provided test script to verify functionality:
```bash
python test_automated_calls.py
```

For detailed documentation, see [AUTOMATED_CALLS_README.md](AUTOMATED_CALLS_README.md).

---

## Linked Repositories
This project is linked to the following repositories:

- [Backend Repository](https://github.com/moomensaleem135/virtual-phone-system-backend)
- [Frontend Repository](https://github.com/moomensaleem135/virtual-phone-frontend)
- [Mobile App Repository](https://github.com/moomensaleem135/On-Call.AI-App)

