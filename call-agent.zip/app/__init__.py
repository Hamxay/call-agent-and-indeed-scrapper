from flask import Flask, jsonify
import logging
import os
from flask_cors import CORS

from app.config import Config
from app.routes.call_management import call_management_bp
from app.utils import setup_logger


def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)

    print(app.config)

    # Setup logger
    logger = setup_logger("app")

    # Register blueprint
    app.register_blueprint(call_management_bp, url_prefix="/calls")

    # CORS configuration (allow all origins)
    CORS(app, resources={r"/*": {"origins": "*"}})

    @app.route("/")
    def index():
        logger.info("Index route accessed")
        # List all routes
        routes = []
        for rule in app.url_map.iter_rules():
            if "static" not in rule.endpoint:  # Skip static routes
                # Extract the URL prefix from the blueprint (if present)
                prefix = (
                    rule.rule.split("/")[1]
                    if rule.rule.startswith("/")
                    else "No Blueprint"
                )

                routes.append(
                    {
                        "endpoint": rule.endpoint,
                        "methods": list(rule.methods),
                        "url": str(rule),
                        "blueprint": prefix,
                    }
                )

        # Group routes by their URL prefix (blueprint) and count them
        grouped_routes = {}
        for route in routes:
            blueprint = route["blueprint"]
            if blueprint not in grouped_routes:
                grouped_routes[blueprint] = {"routes": [], "count": 0}
            grouped_routes[blueprint]["routes"].append(
                {
                    "endpoint": route["endpoint"],
                    "methods": route["methods"],
                    "url": route["url"],
                }
            )
            grouped_routes[blueprint]["count"] += 1

        return jsonify(
            {
                "message": "Welcome to the Call Agent API - Core Functionality Only",
                "routes": grouped_routes,
            }
        )

    setup_logging()
    return app


def setup_logging():
    logging.basicConfig(
        level=logging.INFO, format="%(asctime)s [%(levelname)s] - %(message)s"
    )
