import os
from dotenv import load_dotenv

load_dotenv()


class Config:
    SECRET_KEY = os.getenv("SECRET_KEY", "default_secret_key")
    BASE_URL = os.getenv("BASE_URL")

    # Twilio Configuration
    TWILIO_ACCOUNT_SID = os.getenv("TWILIO_ACCOUNT_SID")
    TWILIO_AUTH_TOKEN = os.getenv("TWILIO_AUTH_TOKEN")
    TWILIO_PHONE_NUMBER = os.getenv("TWILIO_PHONE_NUMBER")
    # TWIML_APP_SID = os.getenv("TWIML_APP_SID")
    TWILIO_CALL_URL = os.getenv("TWILIO_CALL_URL", f"{BASE_URL}/calls/twiml-agent")

    # Lyzr Agent API Configuration
    LYZR_API_KEY = os.getenv(
        "LYZR_API_KEY", "sk-default-TkM2vZ53V0tzne4sNDX1vVtZMow8TDXn"
    )
    LYZR_USER_ID = os.getenv("LYZR_USER_ID", "hamxay341@gmail.com")
    LYZR_AGENT_ID = os.getenv("LYZR_AGENT_ID", "68b94c0c38e044156b375fb4")
