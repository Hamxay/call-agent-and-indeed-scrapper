import os
import time
from datetime import datetime
from flask import Blueprint, request, jsonify, current_app
from twilio.request_validator import RequestValidator
from twilio.twiml.voice_response import VoiceResponse

from app.services.twilio_service import (
    make_outbound_call,
    make_recruitment_call,
    get_call_status,
)
from app.services.lyzr_service import get_lyzr_service
from app.utils import setup_logger

logger = setup_logger("call_management")
call_management_bp = Blueprint("call", __name__)


@call_management_bp.route("/make-call", methods=["POST"])
def make_call():
    """Make an outbound call to test the Lyzr.ai agent."""
    try:
        data = request.get_json()
        if not data or "phone_number" not in data:
            return jsonify({"error": "phone_number is required"}), 400

        phone_number = data["phone_number"]
        message = data.get(
            "message", "Hello! This is a test call from the Lyzr.ai agent system."
        )

        # Store the message for the call
        current_app.config["CALL_MESSAGE"] = message

        logger.info(f"Making outbound call to {phone_number} with message: {message}")

        # Make the call using the conversation-start route for better flow
        call_sid = make_outbound_call(phone_number)

        return (
            jsonify(
                {
                    "success": True,
                    "message": "Call initiated successfully",
                    "call_sid": call_sid,
                    "phone_number": phone_number,
                    "conversation_type": "two_way_interactive",
                    "webhook_url": f"{current_app.config['BASE_URL']}/calls/conversation-start",
                }
            ),
            200,
        )

    except Exception as e:
        logger.error(f"Error making call: {str(e)}")
        return jsonify({"error": str(e)}), 500


@call_management_bp.route("/call-status/<call_sid>", methods=["GET"])
def call_status(call_sid):
    """Get the status of a call."""
    try:
        status = get_call_status(call_sid)
        return jsonify(status), 200
    except Exception as e:
        logger.error(f"Error getting call status: {str(e)}")
        return jsonify({"error": str(e)}), 500


@call_management_bp.route("/twiml-agent", methods=["POST"])
def twiml_agent():
    """TwiML for handling outbound calls with Lyzr.ai agent - Two-way conversation."""
    try:
        # Get Twilio signature from headers for validation
        twilio_signature = request.headers.get("X-Twilio-Signature")

        if twilio_signature:
            # Validate Twilio request
            validator = RequestValidator(current_app.config["TWILIO_AUTH_TOKEN"])

            # Construct the full webhook URL that Twilio expects
            base_url = current_app.config["BASE_URL"]
            if base_url.endswith("/"):
                base_url = base_url[:-1]

            webhook_path = request.path
            if not webhook_path.startswith("/"):
                webhook_path = "/" + webhook_path

            url = base_url + webhook_path
            form_params = request.form.to_dict()

            # Validate the request
            if not validator.validate(url, form_params, twilio_signature):
                logger.warning("Invalid Twilio signature")
                return "Invalid signature", 403

        # Get the message for this call
        message = current_app.config.get("CALL_MESSAGE", "Hello! This is a test call.")

        # Create TwiML response for conversation start
        response = VoiceResponse()

        # Add a pause to let the call connect
        response.pause(length=1)

        # Speak the initial message
        response.say(message, voice="alice", language="en-US")

        # Add a pause
        response.pause(length=1)

        # Start the conversation with Lyzr.ai agent
        try:
            lyzr_service = get_lyzr_service()
            lyzr_response = lyzr_service.send_message(
                "This is a phone call. Please start a conversation by asking the caller a question. Keep your response brief and conversational."
            )
            if lyzr_response.get("success"):
                agent_message = lyzr_response.get("response", {}).get(
                    "response", "Hello! How can I help you today?"
                )
                response.say(agent_message, voice="alice", language="en-US")
            else:
                response.say(
                    "Hello! How can I help you today?",
                    voice="alice",
                    language="en-US",
                )
        except Exception as e:
            logger.error(f"Error getting Lyzr.ai response: {str(e)}")
            response.say(
                "Hello! How can I help you today?",
                voice="alice",
                language="en-US",
            )

        # Add a pause before asking for input
        response.pause(length=1)

        # Use Gather to collect user input
        gather = response.gather(
            input="speech",
            action=f"{current_app.config['BASE_URL']}/calls/conversation-handler",
            method="POST",
            speech_timeout="auto",
            language="en-US",
            enhanced="true",
            speech_model="phone_call",
        )

        # If gather times out or no input, redirect to conversation handler
        response.redirect(
            f"{current_app.config['BASE_URL']}/calls/conversation-handler"
        )

        logger.info("TwiML response generated successfully for conversation start")
        return str(response), 200, {"Content-Type": "text/xml"}

    except Exception as e:
        logger.error(f"Error generating TwiML: {str(e)}")
        # Fallback TwiML
        response = VoiceResponse()
        response.say("Thank you for the call!", voice="alice", language="en-US")
        response.hangup()
        return str(response), 200, {"Content-Type": "text/xml"}


@call_management_bp.route("/dtmf-handler", methods=["POST"])
def dtmf_handler():
    """Handle DTMF (keypad) input from user."""
    try:
        # Get DTMF input from Twilio
        digits = request.form.get("Digits", "")
        call_sid = request.form.get("CallSid", "")

        logger.info(f"DTMF handler called. Digits: {digits}, Call SID: {call_sid}")

        # Create TwiML response
        response = VoiceResponse()

        if digits == "1":
            # Continue conversation
            response.say(
                "Let's continue our conversation. What would you like to discuss?",
                voice="alice",
                language="en-US",
            )

            # Redirect to conversation handler
            response.redirect(
                f"{current_app.config['BASE_URL']}/calls/conversation-handler"
            )

        elif digits == "2":
            # End call
            response.say(
                "Thank you for the conversation. Have a great day!",
                voice="alice",
                language="en-US",
            )
            response.hangup()

        else:
            # Invalid input
            response.say(
                "I didn't understand that input. Please try again.",
                voice="alice",
                language="en-US",
            )
            response.redirect(
                f"{current_app.config['BASE_URL']}/calls/conversation-handler"
            )

        logger.info("DTMF handler completed successfully")
        return str(response), 200, {"Content-Type": "text/xml"}

    except Exception as e:
        logger.error(f"Error in DTMF handler: {str(e)}")
        response = VoiceResponse()
        response.say(
            "I apologize for the technical difficulty. Thank you for calling!",
            voice="alice",
            language="en-US",
        )
        response.hangup()
        return str(response), 200, {"Content-Type": "text/xml"}


@call_management_bp.route("/conversation-start", methods=["POST"])
def conversation_start():
    """Initialize a new conversation session."""
    try:
        # Get call details
        call_sid = request.form.get("CallSid", "")
        from_number = request.form.get("From", "")

        logger.info(
            f"Starting new conversation. Call SID: {call_sid}, From: {from_number}"
        )

        # Create TwiML response
        response = VoiceResponse()

        # Add a pause to let the call connect
        response.pause(length=1)

        # Get the initial message for this call
        message = current_app.config.get("CALL_MESSAGE", "Hello! This is a test call.")
        response.say(message, voice="alice", language="en-US")

        # Add a pause
        response.pause(length=1)

        # Start the conversation with Lyzr.ai agent
        try:
            lyzr_service = get_lyzr_service()

            # Create a session-aware prompt
            prompt = f"This is a new phone call from {from_number}. Please start a conversation by asking the caller a question. Keep your response brief and conversational. This is the beginning of our conversation."

            lyzr_response = lyzr_service.send_message(prompt)

            if lyzr_response.get("success"):
                agent_message = lyzr_response.get("response", {}).get(
                    "response", "Hello! How can I help you today?"
                )
                response.say(agent_message, voice="alice", language="en-US")
            else:
                response.say(
                    "Hello! How can I help you today?",
                    voice="alice",
                    language="en-US",
                )
        except Exception as e:
            logger.error(f"Error getting Lyzr.ai response: {str(e)}")
            response.say(
                "Hello! How can I help you today?",
                voice="alice",
                language="en-US",
            )

        # Add a pause before asking for input
        response.pause(length=1)

        # Use Gather to collect user input - no need to say "I'm listening" here
        gather = response.gather(
            input="speech",
            action=f"{current_app.config['BASE_URL']}/calls/conversation-handler",
            method="POST",
            speech_timeout="auto",
            language="en-US",
            enhanced="true",
            speech_model="phone_call",
        )

        # If gather times out or no input, redirect to conversation handler
        response.redirect(
            f"{current_app.config['BASE_URL']}/calls/conversation-handler"
        )

        logger.info("Conversation start completed successfully")
        return str(response), 200, {"Content-Type": "text/xml"}

    except Exception as e:
        logger.error(f"Error starting conversation: {str(e)}")
        # Fallback TwiML
        response = VoiceResponse()
        response.say("Thank you for the call!", voice="alice", language="en-US")
        response.hangup()
        return str(response), 200, {"Content-Type": "text/xml"}


@call_management_bp.route("/conversation-handler", methods=["POST"])
def conversation_handler():
    """Handle ongoing conversation with user input and AI responses."""
    try:
        # Get user input from Twilio
        user_input = request.form.get("SpeechResult", "")
        call_sid = request.form.get("CallSid", "")
        from_number = request.form.get("From", "")

        logger.info(
            f"Conversation handler called. User input: {user_input}, Call SID: {call_sid}"
        )

        # Create TwiML response
        response = VoiceResponse()

        if user_input:
            # Check if user wants to end the call
            if any(
                word in user_input.lower()
                for word in [
                    "goodbye",
                    "bye",
                    "end call",
                    "hang up",
                    "stop",
                    "that's all",
                    "thank you",
                ]
            ):
                response.say(
                    "Thank you for the conversation. Have a wonderful day!",
                    voice="alice",
                    language="en-US",
                )
                response.hangup()
                return str(response), 200, {"Content-Type": "text/xml"}

            # Process user input with Lyzr.ai agent
            try:
                lyzr_service = get_lyzr_service()

                # Create a context-aware prompt that maintains conversation flow
                prompt = f"User said: '{user_input}'. This is a phone conversation. Please respond naturally and ask a follow-up question to continue the conversation. Keep your response brief and conversational. Remember this is an ongoing conversation, so be engaging."

                lyzr_response = lyzr_service.send_message(prompt)

                if lyzr_response.get("success"):
                    agent_message = lyzr_response.get("response", {}).get(
                        "response", "I understand. Can you tell me more?"
                    )
                    response.say(agent_message, voice="alice", language="en-US")
                else:
                    response.say(
                        "Sorry, I didn't understand that. Can you please repeat?",
                        voice="alice",
                        language="en-US",
                    )
            except Exception as e:
                logger.error(f"Error getting Lyzr.ai response: {str(e)}")
                response.say(
                    "Sorry, I didn't understand that. Can you please repeat?",
                    voice="alice",
                    language="en-US",
                )
        else:
            # No user input received - provide options
            response.say(
                "I didn't catch that. Here are your options:",
                voice="alice",
                language="en-US",
            )
            response.say(
                "Press 1 to continue talking, or press 2 to end the call.",
                voice="alice",
                language="en-US",
            )

            # Use Gather for DTMF input
            gather = response.gather(
                input="dtmf",
                action=f"{current_app.config['BASE_URL']}/calls/dtmf-handler",
                method="POST",
                timeout=10,
                num_digits=1,
            )

            # If no input, redirect to conversation end
            response.redirect(
                f"{current_app.config['BASE_URL']}/calls/conversation-end"
            )
            return str(response), 200, {"Content-Type": "text/xml"}

        # Add a pause after AI response
        response.pause(length=1)

        # Continue the conversation with another Gather - no need to say "I'm listening"
        gather = response.gather(
            input="speech",
            action=f"{current_app.config['BASE_URL']}/calls/conversation-handler",
            method="POST",
            speech_timeout="auto",
            language="en-US",
            enhanced="true",
            speech_model="phone_call",
        )

        # If gather times out, provide simple options
        response.say(
            "If you'd like to continue, just start talking. Or press 1 to continue, 2 to end call.",
            voice="alice",
            language="en-US",
        )

        # Simple DTMF options
        final_gather = response.gather(
            input="dtmf",
            action=f"{current_app.config['BASE_URL']}/calls/dtmf-handler",
            method="POST",
            timeout=10,
            num_digits=1,
        )

        # If no input, end the call
        response.say(
            "Thank you for the conversation. Have a great day!",
            voice="alice",
            language="en-US",
        )
        response.hangup()

        logger.info("Conversation handler completed successfully")
        return str(response), 200, {"Content-Type": "text/xml"}

    except Exception as e:
        logger.error(f"Error in conversation handler: {str(e)}")
        # Fallback TwiML
        response = VoiceResponse()
        response.say(
            "I apologize for the technical difficulty. Thank you for calling!",
            voice="alice",
            language="en-US",
        )
        response.hangup()
        return str(response), 200, {"Content-Type": "text/xml"}


@call_management_bp.route("/conversation-end", methods=["POST"])
def conversation_end():
    """Handle conversation ending gracefully."""
    try:
        response = VoiceResponse()
        response.say(
            "Thank you for the conversation. Have a wonderful day!",
            voice="alice",
            language="en-US",
        )
        response.hangup()

        logger.info("Conversation ended gracefully")
        return str(response), 200, {"Content-Type": "text/xml"}

    except Exception as e:
        logger.error(f"Error ending conversation: {str(e)}")
        response = VoiceResponse()
        response.hangup()
        return str(response), 200, {"Content-Type": "text/xml"}


@call_management_bp.route("/test-lyzr", methods=["POST"])
def test_lyzr_agent():
    """Test the Lyzr.ai agent directly without making a call."""
    try:
        data = request.get_json()
        if not data or "message" not in data:
            return jsonify({"error": "message is required"}), 400

        message = data["message"]
        session_id = data.get("session_id")

        logger.info(f"Testing Lyzr.ai agent with message: {message}")

        # Send message to Lyzr.ai agent
        lyzr_service = get_lyzr_service()
        response = lyzr_service.send_message(message, session_id)

        return jsonify(response), 200

    except Exception as e:
        logger.error(f"Error testing Lyzr.ai agent: {str(e)}")
        return jsonify({"error": str(e)}), 500


@call_management_bp.route("/test-call-scenario", methods=["POST"])
def test_call_scenario():
    """Test a specific call scenario with the Lyzr.ai agent."""
    try:
        data = request.get_json()
        if not data or "scenario" not in data:
            return jsonify({"error": "scenario is required"}), 400

        scenario = data["scenario"]
        phone_number = data.get("phone_number")

        # Define different test scenarios
        scenarios = {
            "greeting": "Please provide a professional greeting for a business call.",
            "sales_inquiry": "I need to inquire about available positions. Please provide a professional inquiry script.",
            "customer_support": "A customer has a complaint. Please provide a helpful response.",
            "appointment_booking": "I need to book an appointment. Please provide a professional booking script.",
        }

        if scenario not in scenarios:
            return (
                jsonify(
                    {
                        "error": f"Unknown scenario. Available scenarios: {list(scenarios.keys())}"
                    }
                ),
                400,
            )

        message = scenarios[scenario]
        logger.info(f"Testing call scenario: {scenario}")

        # Get response from Lyzr.ai agent
        lyzr_service = get_lyzr_service()
        response = lyzr_service.send_message(message)

        result = {
            "scenario": scenario,
            "message": message,
            "lyzr_response": response,
            "phone_number": phone_number,
        }

        # If phone number is provided, also make the call
        if phone_number:
            try:
                call_sid = make_outbound_call(phone_number)
                result["call_sid"] = call_sid
                result["call_initiated"] = True
            except Exception as e:
                result["call_error"] = str(e)
                result["call_initiated"] = False

        return jsonify(result), 200

    except Exception as e:
        logger.error(f"Error testing call scenario: {str(e)}")
        return jsonify({"error": str(e)}), 500


@call_management_bp.route("/recruitment-call", methods=["POST"])
def recruitment_call():
    """Make a recruitment call to agencies with job details."""
    try:
        data = request.get_json()
        if not data or "phone_number" not in data:
            return jsonify({"error": "phone_number is required"}), 400

        if "job_title" not in data:
            return jsonify({"error": "job_title is required"}), 400

        phone_number = data["phone_number"]
        job_title = data["job_title"]
        job_description = data.get("job_description", "")
        company_name = data.get("company_name", "Our Company")
        experience_level = data.get("experience_level", "Not specified")
        salary_range = data.get("salary_range", "Not specified")
        location = data.get("location", "Not specified")

        # Store job details for the call
        current_app.config["RECRUITMENT_DATA"] = {
            "job_title": job_title,
            "job_description": job_description,
            "company_name": company_name,
            "experience_level": experience_level,
            "salary_range": salary_range,
            "location": location,
            "phone_number": phone_number,
            "call_timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
        }

        logger.info(f"Making recruitment call to {phone_number} for job: {job_title}")

        # Make the call using the recruitment-start route
        call_sid = make_recruitment_call(phone_number)

        return (
            jsonify(
                {
                    "success": True,
                    "message": "Recruitment call initiated successfully",
                    "call_sid": call_sid,
                    "phone_number": phone_number,
                    "job_title": job_title,
                    "conversation_type": "recruitment_agency_call",
                    "webhook_url": f"{current_app.config['BASE_URL']}/calls/recruitment-start",
                }
            ),
            200,
        )

    except Exception as e:
        logger.error(f"Error making recruitment call: {str(e)}")
        return jsonify({"error": str(e)}), 500


@call_management_bp.route("/recruitment-start", methods=["POST"])
def recruitment_start():
    """Initialize a recruitment call session with job details."""
    try:
        # Get call details
        call_sid = request.form.get("CallSid", "")
        from_number = request.form.get("From", "")

        # Get recruitment data
        recruitment_data = current_app.config.get("RECRUITMENT_DATA", {})

        logger.info(
            f"Starting recruitment call. Call SID: {call_sid}, From: {from_number}"
        )

        # Create TwiML response
        response = VoiceResponse()

        # Add a pause to let the call connect
        response.pause(length=1)

        # Start the recruitment conversation
        try:
            lyzr_service = get_lyzr_service()

            # Create a recruitment-specific prompt
            prompt = f"""You are calling a recruitment agency as an HR recruiter. 
            
Job Details:
- Title: {recruitment_data.get('job_title', 'Not specified')}
- Company: {recruitment_data.get('company_name', 'Our Company')}
- Experience: {recruitment_data.get('experience_level', 'Not specified')}
- Salary: {recruitment_data.get('salary_range', 'Not specified')}
- Location: {recruitment_data.get('location', 'Not specified')}

Your task: Introduce yourself as an HR recruiter and ask if they have suitable candidates for this position. Be professional, ask specific questions about their candidate pool, and gather information about their recruitment process. Keep responses brief and conversational.

Start by introducing yourself and the position you're recruiting for."""

            lyzr_response = lyzr_service.send_message(prompt)

            if lyzr_response.get("success"):
                agent_message = lyzr_response.get("response", {}).get(
                    "response",
                    f"Hello, I'm calling from {recruitment_data.get('company_name', 'our company')}. We're looking for candidates for a {recruitment_data.get('job_title', 'position')}. Do you have suitable candidates available?",
                )
                response.say(agent_message, voice="alice", language="en-US")
            else:
                response.say(
                    f"Hello, I'm calling from {recruitment_data.get('company_name', 'our company')}. We're looking for candidates for a {recruitment_data.get('job_title', 'position')}. Do you have suitable candidates available?",
                    voice="alice",
                    language="en-US",
                )
        except Exception as e:
            logger.error(f"Error getting Lyzr.ai response: {str(e)}")
            response.say(
                f"Hello, I'm calling from {recruitment_data.get('company_name', 'our company')}. We're looking for candidates for a {recruitment_data.get('job_title', 'position')}. Do you have suitable candidates available?",
                voice="alice",
                language="en-US",
            )

        # Add a pause before asking for input
        response.pause(length=1)

        # Use Gather to collect agency response
        gather = response.gather(
            input="speech",
            action=f"{current_app.config['BASE_URL']}/calls/recruitment-handler",
            method="POST",
            speech_timeout="auto",
            language="en-US",
            enhanced="true",
            speech_model="phone_call",
        )

        # If gather times out or no input, redirect to recruitment handler
        response.redirect(f"{current_app.config['BASE_URL']}/calls/recruitment-handler")

        logger.info("Recruitment start completed successfully")
        return str(response), 200, {"Content-Type": "text/xml"}

    except Exception as e:
        logger.error(f"Error starting recruitment call: {str(e)}")
        # Fallback TwiML
        response = VoiceResponse()
        response.say("Thank you for the call!", voice="alice", language="en-US")
        response.hangup()
        return str(response), 200, {"Content-Type": "text/xml"}


@call_management_bp.route("/recruitment-handler", methods=["POST"])
def recruitment_handler():
    """Handle ongoing recruitment conversation and save data."""
    try:
        # Get user input from Twilio
        user_input = request.form.get("SpeechResult", "")
        call_sid = request.form.get("CallSid", "")
        from_number = request.form.get("From", "")

        # Get recruitment data
        recruitment_data = current_app.config.get("RECRUITMENT_DATA", {})

        logger.info(
            f"Recruitment handler called. User input: {user_input}, Call SID: {call_sid}"
        )

        # Create TwiML response
        response = VoiceResponse()

        if user_input:
            # Check if user wants to end the call
            if any(
                word in user_input.lower()
                for word in [
                    "goodbye",
                    "bye",
                    "end call",
                    "hang up",
                    "stop",
                    "that's all",
                    "thank you",
                    "no candidates",
                    "not available",
                    "call back later",
                ]
            ):
                # Save conversation data before ending
                save_recruitment_data(
                    call_sid, from_number, user_input, "ended_by_agency"
                )

                response.say(
                    "Thank you for your time. We'll be in touch if we need further assistance.",
                    voice="alice",
                    language="en-US",
                )
                response.hangup()
                return str(response), 200, {"Content-Type": "text/xml"}

            # Process agency response with Lyzr.ai agent
            try:
                lyzr_service = get_lyzr_service()

                # Create a recruitment-specific prompt
                prompt = f"""You are in a recruitment call with an agency. 

Job Details: {recruitment_data.get('job_title', 'Not specified')} at {recruitment_data.get('company_name', 'Our Company')}

Agency said: "{user_input}"

Your task: Respond professionally as an HR recruiter. Ask follow-up questions about:
- Candidate availability and experience levels
- Their recruitment process and timeline
- Rates and terms
- Next steps

Keep responses brief, professional, and focused on gathering recruitment information."""

                lyzr_response = lyzr_service.send_message(prompt)

                if lyzr_response.get("success"):
                    agent_message = lyzr_response.get("response", {}).get(
                        "response",
                        "Thank you for that information. Can you tell me more about your candidate pool and recruitment process?",
                    )
                    response.say(agent_message, voice="alice", language="en-US")
                else:
                    response.say(
                        "Thank you for that information. Can you tell me more about your candidate pool and recruitment process?",
                        voice="alice",
                        language="en-US",
                    )
            except Exception as e:
                logger.error(f"Error getting Lyzr.ai response: {str(e)}")
                response.say(
                    "Thank you for that information. Can you tell me more about your candidate pool and recruitment process?",
                    voice="alice",
                    language="en-US",
                )
        else:
            # No user input received - provide options
            response.say(
                "I didn't catch that. Here are your options:",
                voice="alice",
                language="en-US",
            )
            response.say(
                "Press 1 to continue talking, or press 2 to end the call.",
                voice="alice",
                language="en-US",
            )

            # Use Gather for DTMF input
            gather = response.gather(
                input="dtmf",
                action=f"{current_app.config['BASE_URL']}/calls/recruitment-dtmf-handler",
                method="POST",
                timeout=10,
                num_digits=1,
            )

            # If no input, redirect to conversation end
            response.redirect(f"{current_app.config['BASE_URL']}/calls/recruitment-end")
            return str(response), 200, {"Content-Type": "text/xml"}

        # Add a pause after AI response
        response.pause(length=1)

        # Continue the conversation with another Gather
        gather = response.gather(
            input="speech",
            action=f"{current_app.config['BASE_URL']}/calls/recruitment-handler",
            method="POST",
            speech_timeout="auto",
            language="en-US",
            enhanced="true",
            speech_model="phone_call",
        )

        # If gather times out, provide simple options
        response.say(
            "If you'd like to continue, just start talking. Or press 1 to continue, 2 to end call.",
            voice="alice",
            language="en-US",
        )

        # Simple DTMF options
        final_gather = response.gather(
            input="dtmf",
            action=f"{current_app.config['BASE_URL']}/calls/recruitment-dtmf-handler",
            method="POST",
            timeout=10,
            num_digits=1,
        )

        # If no input, save data and end the call
        save_recruitment_data(call_sid, from_number, "No response", "timeout")
        response.say(
            "Thank you for your time. We'll be in touch if we need further assistance.",
            voice="alice",
            language="en-US",
        )
        response.hangup()

        logger.info("Recruitment handler completed successfully")
        return str(response), 200, {"Content-Type": "text/xml"}

    except Exception as e:
        logger.error(f"Error in recruitment handler: {str(e)}")
        # Fallback TwiML
        response = VoiceResponse()
        response.say(
            "I apologize for the technical difficulty. Thank you for calling!",
            voice="alice",
            language="en-US",
        )
        response.hangup()
        return str(response), 200, {"Content-Type": "text/xml"}


@call_management_bp.route("/recruitment-dtmf-handler", methods=["POST"])
def recruitment_dtmf_handler():
    """Handle DTMF input for recruitment calls."""
    try:
        digits = request.form.get("Digits", "")
        call_sid = request.form.get("CallSid", "")
        from_number = request.form.get("From", "")

        logger.info(
            f"Recruitment DTMF handler called. Digits: {digits}, Call SID: {call_sid}"
        )

        response = VoiceResponse()

        if digits == "1":
            response.say(
                "Let's continue our discussion. What would you like to tell me about your recruitment services?",
                voice="alice",
                language="en-US",
            )
            response.redirect(
                f"{current_app.config['BASE_URL']}/calls/recruitment-handler"
            )

        elif digits == "2":
            # Save conversation data before ending
            save_recruitment_data(
                call_sid, from_number, "Ended via keypad", "ended_by_keypad"
            )
            response.say(
                "Thank you for your time. We'll be in touch if we need further assistance.",
                voice="alice",
                language="en-US",
            )
            response.hangup()

        else:
            response.say(
                "I didn't understand that input. Please try again.",
                voice="alice",
                language="en-US",
            )
            response.redirect(
                f"{current_app.config['BASE_URL']}/calls/recruitment-handler"
            )

        logger.info("Recruitment DTMF handler completed successfully")
        return str(response), 200, {"Content-Type": "text/xml"}

    except Exception as e:
        logger.error(f"Error in recruitment DTMF handler: {str(e)}")
        response = VoiceResponse()
        response.say(
            "I apologize for the technical difficulty. Thank you for calling!",
            voice="alice",
            language="en-US",
        )
        response.hangup()
        return str(response), 200, {"Content-Type": "text/xml"}


@call_management_bp.route("/recruitment-end", methods=["POST"])
def recruitment_end():
    """Handle recruitment call ending."""
    try:
        call_sid = request.form.get("CallSid", "")
        from_number = request.form.get("From", "")

        # Save conversation data
        save_recruitment_data(call_sid, from_number, "No response", "ended_by_system")

        response = VoiceResponse()
        response.say(
            "Thank you for your time. We'll be in touch if we need further assistance.",
            voice="alice",
            language="en-US",
        )
        response.hangup()

        logger.info("Recruitment call ended gracefully")
        return str(response), 200, {"Content-Type": "text/xml"}

    except Exception as e:
        logger.error(f"Error ending recruitment call: {str(e)}")
        response = VoiceResponse()
        response.hangup()
        return str(response), 200, {"Content-Type": "text/xml"}


def save_recruitment_data(call_sid, phone_number, last_response, call_status):
    """Save recruitment call data to Excel file."""
    try:
        import pandas as pd
        from datetime import datetime

        recruitment_data = current_app.config.get("RECRUITMENT_DATA", {})

        # Prepare data for saving
        data_to_save = {
            "Call SID": call_sid,
            "Timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "Phone Number": phone_number,
            "Job Title": recruitment_data.get("job_title", ""),
            "Company": recruitment_data.get("company_name", ""),
            "Experience Level": recruitment_data.get("experience_level", ""),
            "Salary Range": recruitment_data.get("salary_range", ""),
            "Location": recruitment_data.get("location", ""),
            "Last Response": last_response,
            "Call Status": call_status,
            "Duration": "N/A",  # Could be calculated if needed
        }

        # Try to load existing file or create new one
        try:
            df = pd.read_excel("recruitment_calls.xlsx")
            df = df.append(data_to_save, ignore_index=True)
        except FileNotFoundError:
            df = pd.DataFrame([data_to_save])

        # Save to Excel
        df.to_excel("recruitment_calls.xlsx", index=False)

        logger.info(f"Recruitment data saved to Excel for call {call_sid}")

    except Exception as e:
        logger.error(f"Error saving recruitment data: {str(e)}")
        # Fallback: save to simple text file
        try:
            with open("recruitment_calls.txt", "a", encoding="utf-8") as f:
                f.write(
                    f"{datetime.now().strftime('%Y-%m-%d %H:%M:%S')} | {call_sid} | {phone_number} | {recruitment_data.get('job_title', '')} | {call_status}\n"
                )
        except Exception as fallback_error:
            logger.error(f"Fallback save also failed: {str(fallback_error)}")


@call_management_bp.route("/get-recruitment-data", methods=["GET"])
def get_recruitment_data():
    """Get all recruitment call data."""
    try:
        import pandas as pd

        try:
            df = pd.read_excel("recruitment_calls.xlsx")
            data = df.to_dict("records")
            return jsonify({"success": True, "data": data}), 200
        except FileNotFoundError:
            return (
                jsonify(
                    {
                        "success": True,
                        "data": [],
                        "message": "No recruitment data found",
                    }
                ),
                200,
            )

    except Exception as e:
        logger.error(f"Error getting recruitment data: {str(e)}")
        return jsonify({"error": str(e)}), 500
