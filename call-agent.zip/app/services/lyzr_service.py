import requests
import json
from flask import current_app
from app.utils import setup_logger

logger = setup_logger("lyzr_service")


class LyzrService:
    """Service for communicating with Lyzr agent API"""

    def __init__(self):
        self.base_url = "https://agent-prod.studio.lyzr.ai/v3/inference/chat/"
        self.api_key = current_app.config.get(
            "LYZR_API_KEY", "sk-default-TkM2vZ53V0tzne4sNDX1vVtZMow8TDXn"
        )
        self.user_id = current_app.config.get("LYZR_USER_ID", "hamxay341@gmail.com")
        self.agent_id = current_app.config.get(
            "LYZR_AGENT_ID", "68b94c0c38e044156b375fb4"
        )

    def send_message(self, message, session_id=None):
        """
        Send a message to the Lyzr agent

        Args:
            message (str): The message to send to the agent
            session_id (str): Optional session ID for conversation continuity

        Returns:
            dict: Response from the Lyzr agent
        """
        try:
            # Generate session ID if not provided
            if not session_id:
                import uuid

                session_id = f"{self.agent_id}-{str(uuid.uuid4())[:8]}"

            payload = {
                "user_id": self.user_id,
                "agent_id": self.agent_id,
                "session_id": session_id,
                "message": message,
            }

            headers = {"Content-Type": "application/json", "x-api-key": self.api_key}

            logger.info(f"Sending message to Lyzr agent: {message[:100]}...")
            logger.info(f"Session ID: {session_id}")

            response = requests.post(
                self.base_url, headers=headers, json=payload, timeout=30
            )

            if response.status_code == 200:
                result = response.json()
                logger.info("Successfully received response from Lyzr agent")
                return {"success": True, "response": result, "session_id": session_id}
            else:
                logger.error(
                    f"Lyzr API error: {response.status_code} - {response.text}"
                )
                return {
                    "success": False,
                    "error": f"API error: {response.status_code}",
                    "session_id": session_id,
                }

        except requests.exceptions.RequestException as e:
            logger.error(f"Request error communicating with Lyzr agent: {str(e)}")
            return {
                "success": False,
                "error": f"Request error: {str(e)}",
                "session_id": session_id,
            }
        except Exception as e:
            logger.error(f"Unexpected error in Lyzr service: {str(e)}")
            return {
                "success": False,
                "error": f"Unexpected error: {str(e)}",
                "session_id": session_id,
            }

    def handle_call_conversation(self, transcript, call_context=None):
        """
        Handle a call conversation by sending transcript to Lyzr agent

        Args:
            transcript (str): The call transcript
            call_context (dict): Additional context about the call

        Returns:
            dict: Response from the Lyzr agent
        """
        try:
            # Prepare message with context
            message = f"Call Transcript: {transcript}"

            if call_context:
                context_str = "\n".join([f"{k}: {v}" for k, v in call_context.items()])
                message += f"\n\nCall Context:\n{context_str}"

            # Send to Lyzr agent
            return self.send_message(message)

        except Exception as e:
            logger.error(f"Error handling call conversation: {str(e)}")
            return {"success": False, "error": f"Error handling conversation: {str(e)}"}

    def get_agent_response_for_role_inquiry(self, role_type, company_info=None):
        """
        Get agent response for specific role inquiries

        Args:
            role_type (str): Type of role (Server, Cook, Housekeeper, Nursing Assistant)
            company_info (dict): Information about the company being contacted

        Returns:
            dict: Response from the Lyzr agent
        """
        try:
            message = f"I need to inquire about available {role_type} positions"

            if company_info:
                company_str = "\n".join([f"{k}: {v}" for k, v in company_info.items()])
                message += f"\n\nCompany Information:\n{company_str}"

            message += "\n\nPlease provide a professional inquiry script for contacting staffing agencies about this role."

            return self.send_message(message)

        except Exception as e:
            logger.error(f"Error getting agent response for role inquiry: {str(e)}")
            return {
                "success": False,
                "error": f"Error getting role inquiry response: {str(e)}",
            }


def get_lyzr_service():
    """Get a LyzrService instance within the application context."""
    return LyzrService()
