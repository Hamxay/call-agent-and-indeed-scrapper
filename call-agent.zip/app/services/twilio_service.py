from flask import current_app
from twilio.rest import Client
from app.utils import setup_logger

# Setup logger
logger = setup_logger("twilio_service")


def get_twilio_client():
    """
    Initialize and return a Twilio client.
    """
    try:
        logger.info("Initializing Twilio client.")
        client = Client(
            current_app.config["TWILIO_ACCOUNT_SID"],
            current_app.config["TWILIO_AUTH_TOKEN"],
        )
        logger.info("Twilio client initialized successfully.")
        return client
    except Exception as e:
        logger.error(f"Error initializing Twilio client: {str(e)}", exc_info=True)
        raise


def make_outbound_call(to_phone_number: str):
    """
    Make an outbound call using Twilio.
    """
    try:
        logger.info(f"Making outbound call to {to_phone_number}.")
        account_sid = current_app.config["TWILIO_ACCOUNT_SID"]
        auth_token = current_app.config["TWILIO_AUTH_TOKEN"]
        from_phone_number = current_app.config["TWILIO_PHONE_NUMBER"]
        client = Client(account_sid, auth_token)
        logger.info("Twilio client created successfully.")

        # Use the conversation-start route for better conversation flow
        webhook_url = f"{current_app.config['BASE_URL']}/calls/conversation-start"

        call = client.calls.create(
            to=to_phone_number,
            from_=from_phone_number,
            url=webhook_url,
            record=True,
            method="POST",
        )
        logger.info(f"Outbound call initiated successfully. Call SID: {call.sid}.")
        return call.sid

    except Exception as e:
        logger.error(f"Error making outbound call: {str(e)}", exc_info=True)
        raise


def make_recruitment_call(to_phone_number: str):
    """
    Make a recruitment call using Twilio.
    """
    try:
        logger.info(f"Making recruitment call to {to_phone_number}.")
        account_sid = current_app.config["TWILIO_ACCOUNT_SID"]
        auth_token = current_app.config["TWILIO_AUTH_TOKEN"]
        from_phone_number = current_app.config["TWILIO_PHONE_NUMBER"]
        client = Client(account_sid, auth_token)
        logger.info("Twilio client created successfully for recruitment call.")

        # Use the recruitment-start route for recruitment calls
        webhook_url = f"{current_app.config['BASE_URL']}/calls/recruitment-start"

        call = client.calls.create(
            to=to_phone_number,
            from_=from_phone_number,
            url=webhook_url,
            record=True,
            method="POST",
        )
        logger.info(f"Recruitment call initiated successfully. Call SID: {call.sid}.")
        return call.sid

    except Exception as e:
        logger.error(f"Error making recruitment call: {str(e)}", exc_info=True)
        raise


def get_call_status(call_sid: str):
    """
    Get the status of a call.
    """
    try:
        client = get_twilio_client()
        call = client.calls(call_sid).fetch()
        return {
            "call_sid": call.sid,
            "status": call.status,
            "duration": call.duration,
            "start_time": call.start_time,
            "end_time": call.end_time,
        }
    except Exception as e:
        logger.error(f"Error getting call status: {str(e)}", exc_info=True)
        raise
