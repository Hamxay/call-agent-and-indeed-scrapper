import logging
import os
import requests
from requests.auth import HTTPBasicAuth


TWILIO_AUTH_TOKEN = os.getenv("TWILIO_AUTH_TOKEN")
TWILIO_ACCOUNT_SID = os.getenv("TWILIO_ACCOUNT_SID")


def setup_logger(name: str, level=logging.INFO) -> logging.Logger:
    """Set up a logger."""
    logger = logging.getLogger(name)
    formatter = logging.Formatter(
        "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
    )
    logger.setLevel(level)
    return logger


def convert_audio_to_wav(recording_url: str, output_path: str) -> str:
    """
    Convert an audio file from a remote URL to WAV format.

    Args:
        recording_url (str): The URL of the recording to download.
        output_path (str): The path to save the downloaded audio file.

    Returns:
        str: The path of the converted WAV file.
    """
    try:
        logger = setup_logger("AudioConversion")
        logger.info(f"Downloading audio from URL: {recording_url}.")
        response = requests.get(
            recording_url, auth=HTTPBasicAuth(TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN)
        )
        response.raise_for_status()
        with open(output_path, "wb") as f:
            f.write(response.content)
        logger.info(f"Audio downloaded successfully and saved to: {output_path}.")
        return output_path

    except Exception as e:
        logger.error(f"Error in converting audio to WAV: {str(e)}", exc_info=True)


def validate_param(param_name, param_value):
    """Helper function to validate integer parameters."""
    try:
        value = int(param_value)
        if value < 1:
            raise ValueError(f"'{param_name}' must be a positive integer.")
        return value
    except ValueError:
        raise ValueError(
            f"'{param_name}' parameter is invalid: '{param_value}' is not a valid positive integer."
        )
