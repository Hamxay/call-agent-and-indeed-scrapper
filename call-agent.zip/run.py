#!/usr/bin/env python3
"""
Simple startup script for the Call Agent application.
"""

from app import create_app

if __name__ == "__main__":
    app = create_app()
    print("🚀 Starting Call Agent - Core Functionality")
    print("📍 Server will be available at: http://localhost:5000")
    print("📖 API documentation available at: http://localhost:5000/")
    print("🔧 Press Ctrl+C to stop the server")
    print("-" * 60)

    app.run(debug=True, host="0.0.0.0", port=5000)
