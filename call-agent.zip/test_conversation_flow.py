#!/usr/bin/env python3
"""
Test script for the new two-way conversation flow.
"""

import requests
import json
import time


def test_conversation_flow():
    """Test the new conversation flow."""

    # Your ngrok URL
    base_url = "https://c74b3ace3249.ngrok-free.app"

    print("🧪 Testing Two-Way Conversation Flow")
    print("=" * 50)

    # Test 1: Make a call
    print("\n1️⃣ Testing call initiation...")
    call_data = {
        "phone_number": "+923030190741",
        "message": "Hello! This is a test call from the Lyzr.ai agent system. Let's have a conversation!",
    }

    try:
        response = requests.post(
            f"{base_url}/calls/make-call",
            json=call_data,
            headers={"Content-Type": "application/json"},
        )

        if response.status_code == 200:
            result = response.json()
            print(f"✅ Call initiated successfully!")
            print(f"   Call SID: {result.get('call_sid')}")
            print(f"   Conversation Type: {result.get('conversation_type')}")
            print(f"   Webhook URL: {result.get('webhook_url')}")

            # Test 2: Check call status
            print("\n2️⃣ Testing call status...")
            time.sleep(2)  # Wait a bit for the call to process

            status_response = requests.get(
                f"{base_url}/calls/call-status/{result.get('call_sid')}",
                headers={"Content-Type": "application/json"},
            )

            if status_response.status_code == 200:
                status_result = status_response.json()
                print(f"✅ Call status retrieved!")
                print(f"   Status: {status_result.get('status')}")
                print(f"   Duration: {status_result.get('duration')}")
            else:
                print(f"❌ Failed to get call status: {status_response.status_code}")

        else:
            print(f"❌ Failed to initiate call: {response.status_code}")
            print(f"   Response: {response.text}")

    except Exception as e:
        print(f"❌ Error testing call flow: {str(e)}")

    # Test 3: Test Lyzr agent directly
    print("\n3️⃣ Testing Lyzr agent directly...")
    try:
        lyzr_data = {
            "message": "This is a test message. Please respond with a question to continue our conversation.",
            "session_id": "test_session_001",
        }

        lyzr_response = requests.post(
            f"{base_url}/calls/test-lyzr",
            json=lyzr_data,
            headers={"Content-Type": "application/json"},
        )

        if lyzr_response.status_code == 200:
            lyzr_result = lyzr_response.json()
            print(f"✅ Lyzr agent test successful!")
            if lyzr_result.get("success"):
                print(
                    f"   Response: {lyzr_result.get('response', {}).get('response', 'No response')}"
                )
            else:
                print(f"   Error: {lyzr_result.get('error', 'Unknown error')}")
        else:
            print(f"❌ Lyzr agent test failed: {lyzr_response.status_code}")

    except Exception as e:
        print(f"❌ Error testing Lyzr agent: {str(e)}")

    print("\n" + "=" * 50)
    print("🎯 Conversation Flow Test Complete!")
    print("\n📱 To test the actual conversation:")
    print("   1. Make sure your phone number is configured in Twilio")
    print("   2. The call will use the new conversation-start route")
    print("   3. The AI agent will ask questions and listen for responses")
    print("   4. Users can speak naturally or use keypad options")
    print("   5. Say 'goodbye' to end the call naturally")


if __name__ == "__main__":
    test_conversation_flow()
