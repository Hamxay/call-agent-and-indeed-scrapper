#!/usr/bin/env python3
"""
Test script for the core Call Agent functionality.
This script tests the main endpoints without requiring actual Twilio credentials.
"""

import requests
import json
import time

# Base URL for the API
BASE_URL = "http://localhost:5000"


def test_index_endpoint():
    """Test the main index endpoint."""
    print("Testing index endpoint...")
    try:
        response = requests.get(f"{BASE_URL}/")
        if response.status_code == 200:
            data = response.json()
            print(f"✅ Index endpoint working: {data['message']}")
            print(f"Available routes: {len(data['routes'])}")
            return True
        else:
            print(f"❌ Index endpoint failed: {response.status_code}")
            return False
    except Exception as e:
        print(f"❌ Index endpoint error: {e}")
        return False


def test_lyzr_agent():
    """Test the Lyzr.ai agent endpoint."""
    print("\nTesting Lyzr.ai agent endpoint...")
    try:
        payload = {"message": "Please provide a brief greeting for a business call."}
        response = requests.post(f"{BASE_URL}/calls/test-lyzr", json=payload)
        if response.status_code == 200:
            data = response.json()
            print("✅ Lyzr.ai agent endpoint working")
            if data.get("success"):
                print(
                    f"Agent response: {data.get('response', {}).get('response', 'No response')[:100]}..."
                )
            else:
                print(f"Agent error: {data.get('error', 'Unknown error')}")
            return True
        else:
            print(f"❌ Lyzr.ai agent endpoint failed: {response.status_code}")
            print(f"Response: {response.text}")
            return False
    except Exception as e:
        print(f"❌ Lyzr.ai agent endpoint error: {e}")
        return False


def test_call_scenario():
    """Test the call scenario endpoint."""
    print("\nTesting call scenario endpoint...")
    try:
        payload = {"scenario": "greeting"}
        response = requests.post(f"{BASE_URL}/calls/test-call-scenario", json=payload)
        if response.status_code == 200:
            data = response.json()
            print("✅ Call scenario endpoint working")
            print(f"Scenario: {data.get('scenario')}")
            if data.get("lyzr_response", {}).get("success"):
                print(
                    f"Agent response: {data.get('lyzr_response', {}).get('response', {}).get('response', 'No response')[:100]}..."
                )
            else:
                print(
                    f"Agent error: {data.get('lyzr_response', {}).get('error', 'Unknown error')}"
                )
            return True
        else:
            print(f"❌ Call scenario endpoint failed: {response.status_code}")
            print(f"Response: {response.text}")
            return False
    except Exception as e:
        print(f"❌ Call scenario endpoint error: {e}")
        return False


def test_make_call_endpoint():
    """Test the make call endpoint (without actual call)."""
    print("\nTesting make call endpoint...")
    try:
        payload = {
            "phone_number": "+1234567890",
            "message": "This is a test call from the testing script.",
        }
        response = requests.post(f"{BASE_URL}/calls/make-call", json=payload)
        if response.status_code == 200:
            data = response.json()
            print("✅ Make call endpoint working")
            print(f"Call SID: {data.get('call_sid')}")
            return True
        else:
            print(f"❌ Make call endpoint failed: {response.status_code}")
            print(f"Response: {response.text}")
            return False
    except Exception as e:
        print(f"❌ Make call endpoint error: {e}")
        return False


def main():
    """Run all tests."""
    print("🚀 Testing Call Agent Core Functionality")
    print("=" * 50)

    # Test endpoints
    tests = [
        test_index_endpoint,
        test_lyzr_agent,
        test_call_scenario,
        test_make_call_endpoint,
    ]

    passed = 0
    total = len(tests)

    for test in tests:
        if test():
            passed += 1
        time.sleep(1)  # Small delay between tests

    print("\n" + "=" * 50)
    print(f"Test Results: {passed}/{total} tests passed")

    if passed == total:
        print("🎉 All tests passed! The core functionality is working correctly.")
    else:
        print("⚠️  Some tests failed. Check the output above for details.")

    print(
        "\nNote: The make call test may fail if Twilio credentials are not configured."
    )
    print("This is expected behavior for testing purposes.")


if __name__ == "__main__":
    main()
