#!/usr/bin/env python3
"""
Test script for the recruitment call flow.
"""

import requests
import json
import time


def test_recruitment_flow():
    """Test the recruitment call flow."""

    # Your ngrok URL
    base_url = "https://c74b3ace3249.ngrok-free.app"

    print("🏢 Testing Recruitment Agency Call Flow")
    print("=" * 60)

    # Test 1: Make a recruitment call
    print("\n1️⃣ Testing recruitment call initiation...")
    recruitment_data = {
        "phone_number": "+923030190741",
        "job_title": "Senior Python Developer",
        "job_description": "We need a senior Python developer with 5+ years experience in web development",
        "company_name": "TechCorp Solutions",
        "experience_level": "5+ years",
        "salary_range": "$80,000 - $120,000",
        "location": "Remote/New York",
    }

    try:
        response = requests.post(
            f"{base_url}/calls/recruitment-call",
            json=recruitment_data,
            headers={"Content-Type": "application/json"},
        )

        if response.status_code == 200:
            result = response.json()
            print(f"✅ Recruitment call initiated successfully!")
            print(f"   Call SID: {result.get('call_sid')}")
            print(f"   Job Title: {result.get('job_title')}")
            print(f"   Company: {recruitment_data.get('company_name')}")
            print(f"   Conversation Type: {result.get('conversation_type')}")
            print(f"   Webhook URL: {result.get('webhook_url')}")

            # Test 2: Check call status
            print("\n2️⃣ Testing call status...")
            time.sleep(2)  # Wait a bit for the call to process

            status_response = requests.get(
                f"{base_url}/calls/call-status/{result.get('call_sid')}",
                headers={"Content-Type": "application/json"},
            )

            if status_response.status_code == 200:
                status_result = status_response.json()
                print(f"✅ Call status retrieved!")
                print(f"   Status: {status_result.get('status')}")
                print(f"   Duration: {status_result.get('duration')}")
            else:
                print(f"❌ Failed to get call status: {status_response.status_code}")

        else:
            print(f"❌ Failed to initiate recruitment call: {response.status_code}")
            print(f"   Response: {response.text}")

    except Exception as e:
        print(f"❌ Error testing recruitment call flow: {str(e)}")

    # Test 3: Test Lyzr agent with recruitment context
    print("\n3️⃣ Testing Lyzr agent with recruitment context...")
    try:
        lyzr_data = {
            "message": "I'm calling as an HR recruiter looking for Python developers. Do you have suitable candidates available?",
            "session_id": "recruitment_test_001",
        }

        lyzr_response = requests.post(
            f"{base_url}/calls/test-lyzr",
            json=lyzr_data,
            headers={"Content-Type": "application/json"},
        )

        if lyzr_response.status_code == 200:
            lyzr_result = lyzr_response.json()
            print(f"✅ Lyzr agent test successful!")
            if lyzr_result.get("success"):
                print(
                    f"   Response: {lyzr_result.get('response', {}).get('response', 'No response')}"
                )
            else:
                print(f"   Error: {lyzr_result.get('error', 'Unknown error')}")
        else:
            print(f"❌ Lyzr agent test failed: {lyzr_response.status_code}")

    except Exception as e:
        print(f"❌ Error testing Lyzr agent: {str(e)}")

    # Test 4: Get recruitment data (if any exists)
    print("\n4️⃣ Testing recruitment data retrieval...")
    try:
        data_response = requests.get(
            f"{base_url}/calls/get-recruitment-data",
            headers={"Content-Type": "application/json"},
        )

        if data_response.status_code == 200:
            data_result = data_response.json()
            print(f"✅ Recruitment data retrieved!")
            if data_result.get("data"):
                print(
                    f"   Found {len(data_result.get('data'))} recruitment call records"
                )
                for record in data_result.get("data")[:3]:  # Show first 3 records
                    print(
                        f"     - {record.get('Job Title')} | {record.get('Phone Number')} | {record.get('Call Status')}"
                    )
            else:
                print(f"   No recruitment data found yet")
        else:
            print(f"❌ Failed to get recruitment data: {data_response.status_code}")

    except Exception as e:
        print(f"❌ Error testing data retrieval: {str(e)}")

    print("\n" + "=" * 60)
    print("🎯 Recruitment Flow Test Complete!")
    print("\n📱 To test the actual recruitment call:")
    print("   1. Make sure your phone number is configured in Twilio")
    print("   2. The call will use the new recruitment-start route")
    print("   3. The AI agent will act as an HR recruiter")
    print("   4. Job details will be included in the conversation")
    print("   5. All conversation data will be saved to Excel")
    print("\n📊 Data Storage:")
    print("   - Excel file: recruitment_calls.xlsx")
    print("   - Fallback: recruitment_calls.txt")
    print("   - Includes: Job details, call status, responses, timestamps")


def test_multiple_jobs():
    """Test multiple job recruitment calls."""

    base_url = "https://c74b3ace3249.ngrok-free.app"

    print("\n🔢 Testing Multiple Job Recruitment Calls")
    print("=" * 50)

    jobs = [
        {
            "phone_number": "+923030190741",
            "job_title": "Frontend Developer",
            "company_name": "WebTech Solutions",
            "experience_level": "3+ years",
            "salary_range": "$60,000 - $90,000",
            "location": "San Francisco",
        },
        {
            "phone_number": "+923030190741",
            "job_title": "DevOps Engineer",
            "company_name": "CloudCorp",
            "experience_level": "4+ years",
            "salary_range": "$90,000 - $130,000",
            "location": "Remote",
        },
    ]

    for i, job in enumerate(jobs, 1):
        print(f"\n📞 Testing Job {i}: {job['job_title']}")
        try:
            response = requests.post(
                f"{base_url}/calls/recruitment-call",
                json=job,
                headers={"Content-Type": "application/json"},
            )

            if response.status_code == 200:
                result = response.json()
                print(f"   ✅ Call initiated for {job['job_title']}")
                print(f"   📞 Call SID: {result.get('call_sid')}")
            else:
                print(f"   ❌ Failed to initiate call: {response.status_code}")

        except Exception as e:
            print(f"   ❌ Error: {str(e)}")

        time.sleep(1)  # Small delay between calls


if __name__ == "__main__":
    test_recruitment_flow()
    test_multiple_jobs()
